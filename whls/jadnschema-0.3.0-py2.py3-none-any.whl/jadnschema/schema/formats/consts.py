"""
JADN Validation Constants
"""
__all__ = ["HOSTNAME_MAX_LENGTH"]

# Format Validation constants
HOSTNAME_MAX_LENGTH = 255
